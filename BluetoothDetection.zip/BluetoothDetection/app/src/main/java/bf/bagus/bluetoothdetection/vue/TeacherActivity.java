package bf.bagus.bluetoothdetection.vue;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import bf.bagus.bluetoothdetection.R;
import bf.bagus.bluetoothdetection.modele.ModuleModel;
import bf.bagus.bluetoothdetection.modele.TeacherModel;
import bf.bagus.bluetoothdetection.outils.MesOutils;

public class TeacherActivity extends AppCompatActivity {
    private RecyclerView recyclerTeacher;
    private TeacherAdapter teacherAdapter;
    private SearchView searchTeacher;
    private List<TeacherModel> teacherData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher);

        teacherBackData();

        teacherAddData();
        teacherSearch();
        recyclerAdapter();
    }

    private void teacherBackData() {
        ImageView teacherBack = findViewById(R.id.teacherBack);

        teacherBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(TeacherActivity.this, DashboardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }

    private void teacherAddData() {
        ImageView teacherAdd = findViewById(R.id.teacherAdd);

        teacherAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(TeacherActivity.this);
                dialog.setContentView(R.layout.teacher_update);
                EditText edtAddImage = dialog.findViewById(R.id.teacherImage);
                EditText edtAddRegistrationNumber = dialog.findViewById(R.id.teacherRegistrationNumber);
                EditText edtAddLastName = dialog.findViewById(R.id.teacherLastName);
                EditText edtAddFirstName = dialog.findViewById(R.id.teacherFirstName);
                EditText edtAddPhone = dialog.findViewById(R.id.teacherPhone);
                ImageView btnClose = dialog.findViewById(R.id.teacherAddClose);
                Button btnAddButton = dialog.findViewById(R.id.teacherButton);

                btnAddButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String addRegistrationNumber="", addLastName="", addFirstName="", addPhone="";

                        if(!edtAddRegistrationNumber.getText().toString().equals("")){
                            addRegistrationNumber = edtAddRegistrationNumber.getText().toString();
                        }else{
                            MesOutils.showToast(TeacherActivity.this, "Please Enter Registration Number", Toast.LENGTH_SHORT);
                        }
                        if(!edtAddLastName.getText().toString().equals("")){
                            addLastName = edtAddLastName.getText().toString();
                        }else{
                            MesOutils.showToast(TeacherActivity.this, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtAddLastName.getText().toString().equals("")){
                            addLastName = edtAddLastName.getText().toString();
                        }else{
                            MesOutils.showToast(TeacherActivity.this, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtAddFirstName.getText().toString().equals("")){
                            addFirstName = edtAddFirstName.getText().toString();
                        }else{
                            MesOutils.showToast(TeacherActivity.this, "Please Enter First Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtAddPhone.getText().toString().equals("")){
                            addPhone = edtAddPhone.getText().toString();
                        }else{
                            MesOutils.showToast(TeacherActivity.this, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }


                        teacherAdd(R.drawable.ic_widgets, addRegistrationNumber, addLastName, addFirstName, addPhone);
                        teacherAdapter.notifyItemInserted(teacherData.size() -1);
                        recyclerTeacher.scrollToPosition(teacherData.size() -1);
                        dialog.dismiss();
                    }
                });

                btnClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });

    }

    private void teacherAdd(int ic_widgets, String addRegistrationNumber, String addLastName, String addFirstName, String addPhone) {
        teacherData.add(new TeacherModel(ic_widgets, addRegistrationNumber, addLastName, addFirstName, addPhone));
    }

    private void teacherSearch() {
        searchTeacher = findViewById(R.id.searchTeacher);
        searchTeacher.clearFocus();
        searchTeacher.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                filterTeacher(s);
                return true;
            }
        });

        recyclerTeacher = (RecyclerView) findViewById(R.id.recyclerTeacher);

    }

    private void filterTeacher(String s) {
        List<TeacherModel> filteredTeacher = new ArrayList<>();
        for (TeacherModel itemTeacher : teacherData){
            if(itemTeacher.getTeacher_last_name().toLowerCase().contains(s.toLowerCase())){
                filteredTeacher.add(itemTeacher);
            }
        }

        if(filteredTeacher.isEmpty()){
            MesOutils.showToast(this, "No data found", Toast.LENGTH_LONG);
        }else{
            teacherAdapter.setFilteredTeacher(filteredTeacher);
        }
    }

    private void recyclerAdapter() {
        teacherData = new ArrayList<>();

        recyclerTeacher.setHasFixedSize(true);
        recyclerTeacher.setLayoutManager(new LinearLayoutManager(this));

        recyclerAddData();

        teacherAdapter = new TeacherAdapter(this, teacherData);
        recyclerTeacher.setAdapter(teacherAdapter);
    }

    private void recyclerAddData() {
        teacherAdd(R.drawable.ic_teacher, "M2022@007", "Odg", "Ali", "+226 78980239");
        teacherAdd(R.drawable.ic_teacher, "M2022@001", "Kbr", "Omar", "+226 78980239");
        teacherAdd(R.drawable.ic_teacher, "M2022@0011", "Bmc", "Ali", "+226 78980239");
        teacherAdd(R.drawable.ic_teacher, "M2022@0023", "Odg", "Alain", "+226 78980239");
        teacherAdd(R.drawable.ic_teacher, "M2022@0044", "King", "Tal", "+226 78980239");
        teacherAdd(R.drawable.ic_teacher, "M2022@0093", "Odg", "Ali", "+226 78980239");
    }

}