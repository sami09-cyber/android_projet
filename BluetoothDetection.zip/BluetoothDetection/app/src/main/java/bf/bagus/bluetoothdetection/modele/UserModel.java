package bf.bagus.bluetoothdetection.modele;

public class UserModel {
    private int user_image;
    private String user_registration_number;
    private String user_last_name;
    private String user_first_name;
    private String user_phone;
    private String user_bluetooth;

    public UserModel(int user_image, String user_registration_number, String user_last_name, String user_first_name, String user_phone, String user_bluetooth) {
        this.user_image = user_image;
        this.user_registration_number = user_registration_number;
        this.user_last_name = user_last_name;
        this.user_first_name = user_first_name;
        this.user_phone = user_phone;
        this.user_bluetooth = user_bluetooth;
    }

    public int getUser_image() {
        return user_image;
    }

    public void setUser_image(int user_image) {
        this.user_image = user_image;
    }

    public String getUser_registration_number() {
        return user_registration_number;
    }

    public void setUser_registration_number(String user_registration_number) {
        this.user_registration_number = user_registration_number;
    }

    public String getUser_last_name() {
        return user_last_name;
    }

    public void setUser_last_name(String user_last_name) {
        this.user_last_name = user_last_name;
    }

    public String getUser_first_name() {
        return user_first_name;
    }

    public void setUser_first_name(String user_first_name) {
        this.user_first_name = user_first_name;
    }

    public String getUser_phone() {
        return user_phone;
    }

    public void setUser_phone(String user_phone) {
        this.user_phone = user_phone;
    }

    public String getUser_bluetooth() {
        return user_bluetooth;
    }

    public void setUser_bluetooth(String user_bluetooth) {
        this.user_bluetooth = user_bluetooth;
    }
}