package bf.bagus.bluetoothdetection.vue;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import bf.bagus.bluetoothdetection.R;
import bf.bagus.bluetoothdetection.outils.MesOutils;

public class DashboardActivity extends AppCompatActivity {
    CardView cardHome;
    CardView cardTeacher;
    CardView cardUser;
    CardView cardModule;
    CardView cardAbout;
    CardView cardLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        init();

        goToActivity(cardHome, HomeActivity.class);

        goToActivity(cardTeacher, TeacherActivity.class);

        goToActivity(cardModule, ModuleActivity.class);

        goToActivity(cardUser, UserActivity.class);

        cardLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(DashboardActivity.this)
                        .setTitle("Exit")
                        .setMessage("Are you sure want to exit")
                        .setIcon(R.drawable.ic_alert)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                System.exit(0);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener(){
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        })
                        .show();
            }
        });
    }

    /**
     * initialisation
     */
    private void init(){
        cardHome = findViewById(R.id.cardHome);
        cardTeacher = findViewById(R.id.cardTeacher);
        cardUser = findViewById(R.id.cardUser);
        cardModule = findViewById(R.id.cardModule);
        cardAbout = findViewById(R.id.cardAbout);
        cardLogout = findViewById(R.id.cardLogout);
    }

    /**
     * ouvrir l'activity correspondante
     * @param btn
     * @param classe
     */
    private void goToActivity(CardView btn, Class classe){
        btn.setOnClickListener(new ImageButton.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(DashboardActivity.this, classe);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }

}
