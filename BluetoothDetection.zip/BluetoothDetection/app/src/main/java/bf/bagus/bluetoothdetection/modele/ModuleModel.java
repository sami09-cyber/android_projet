package bf.bagus.bluetoothdetection.modele;

public class ModuleModel {
    private int module_image_id;
    private String module_name;
    private String module_description;

    public ModuleModel(int module_image_id, String module_name, String module_description) {
        this.module_image_id = module_image_id;
        this.module_name = module_name;
        this.module_description = module_description;
    }


    public ModuleModel(String module_name, String module_description) {
        this.module_name = module_name;
        this.module_description = module_description;
    }

    public int getModule_image_id() {
        return module_image_id;
    }

    public void setModule_image_id(int module_image_id) {
        this.module_image_id = module_image_id;
    }

    public String getModule_name() {
        return module_name;
    }

    public void setModule_name(String module_name) {
        this.module_name = module_name;
    }

    public String getModule_description() {
        return module_description;
    }

    public void setModule_description(String module_description) {
        this.module_description = module_description;
    }
}
