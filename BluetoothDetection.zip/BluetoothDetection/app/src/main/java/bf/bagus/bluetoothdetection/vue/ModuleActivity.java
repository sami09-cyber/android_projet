package bf.bagus.bluetoothdetection.vue;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import bf.bagus.bluetoothdetection.R;
import bf.bagus.bluetoothdetection.modele.ModuleModel;
import bf.bagus.bluetoothdetection.outils.MesOutils;

public class ModuleActivity extends AppCompatActivity {
    private RecyclerView recyclerModule;
    private ModuleAdapter moduleAdapter;
    private SearchView searchModule;
    private List<ModuleModel> moduleData;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module);

        moduleBackData();

        moduleAddData();
        moduleSearch();
        recyclerAdapter();

        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void moduleBackData() {
        ImageView moduleBack = findViewById(R.id.moduleBack);

        moduleBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ModuleActivity.this, DashboardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }

    private void moduleAddData() {
        ImageView moduleAdd = findViewById(R.id.moduleAdd);

        moduleAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(ModuleActivity.this);
                dialog.setContentView(R.layout.module_update);
                EditText edtAddImage = dialog.findViewById(R.id.moduleImage);
                EditText edtAddName = dialog.findViewById(R.id.moduleName);
                EditText edtAddDescription = dialog.findViewById(R.id.moduleDescription);
                ImageView btnClose = dialog.findViewById(R.id.moduleAddClose);
                Button btnAddButton = dialog.findViewById(R.id.moduleButton);

                btnAddButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String addImage="", addName="", addDescription="";
//                        if(!edtUpdateImage.getText().toString().equals("")){
//                            addImage = edtUpdateImage.getText().toString();
//                        }else{
//                            MesOutils.showToast(ModuleActivity.this, "Please Enter Module Image !", Toast.LENGTH_SHORT);
//                        }
                        if(!edtAddName.getText().toString().equals("")){
                            addName = edtAddName.getText().toString();
                        }else{
                            MesOutils.showToast(ModuleActivity.this, "Please Enter Module Name 1", Toast.LENGTH_SHORT);
                        }
                        if(!edtAddDescription.getText().toString().equals("")){
                            addDescription = edtAddDescription.getText().toString();
                        }else{
                            MesOutils.showToast(ModuleActivity.this, "Please Enter Module Name 1", Toast.LENGTH_SHORT);
                        }

                        moduleAdd(R.drawable.ic_widgets, addName, addDescription);
                        moduleAdapter.notifyItemInserted(moduleData.size() -1);
                        recyclerModule.scrollToPosition(moduleData.size() -1);
                        dialog.dismiss();
                    }
                });

                btnClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });
    }

    private void moduleAdd(int module_image_id, String module_name, String module_description){
        moduleData.add(new ModuleModel(module_image_id, module_name, module_description));
    }

    private void moduleSearch(){
        searchModule = findViewById(R.id.searchModule);
        searchModule.clearFocus();
        searchModule.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                filterModule(s);
                return true;
            }
        });

        recyclerModule = (RecyclerView) findViewById(R.id.recyclerModule);
    }

    private void recyclerAdapter(){
        moduleData = new ArrayList<>();

        recyclerModule.setHasFixedSize(true);
        recyclerModule.setLayoutManager(new LinearLayoutManager(this));

        recyclerAddData();

        moduleAdapter = new ModuleAdapter(this, moduleData);
        recyclerModule.setAdapter(moduleAdapter);
    }

    private void recyclerAddData(){
        moduleData.add(new ModuleModel(R.drawable.ic_widgets, "Algebra", "the part of mathematics in which..."));
        moduleData.add(new ModuleModel(R.drawable.ic_settings, "Analysis", "the part of mathematics in which..."));
        moduleData.add(new ModuleModel(R.drawable.ic_widgets, "French", "the part of mathematics in which..."));
        moduleData.add(new ModuleModel(R.drawable.ic_settings, "English", "the part of mathematics in which.."));
        moduleData.add(new ModuleModel(R.drawable.ic_widgets, "Logical", "the part of mathematics in which..."));
        moduleData.add(new ModuleModel(R.drawable.ic_settings, "Electronic", "the part of mathematics in which..."));
        moduleData.add(new ModuleModel(R.drawable.ic_widgets, "Statistic", "the part of mathematics in which..."));
    }

    private void filterModule(String s) {
        List<ModuleModel> filteredModule = new ArrayList<>();
        for (ModuleModel itemModule : moduleData){
            if(itemModule.getModule_name().toLowerCase().contains(s.toLowerCase())){
                filteredModule.add(itemModule);
            }
        }

        if(filteredModule.isEmpty()){
            MesOutils.showToast(this, "No data found", Toast.LENGTH_LONG);
        }else{
            moduleAdapter.setFilteredModule(filteredModule);
        }
    }
}