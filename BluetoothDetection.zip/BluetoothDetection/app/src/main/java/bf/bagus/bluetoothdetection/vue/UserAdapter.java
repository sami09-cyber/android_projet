package bf.bagus.bluetoothdetection.vue;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import bf.bagus.bluetoothdetection.R;
import bf.bagus.bluetoothdetection.modele.TeacherModel;
import bf.bagus.bluetoothdetection.modele.UserModel;
import bf.bagus.bluetoothdetection.outils.MesOutils;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {
    Context context;
    public List<UserModel> userData;

    public UserAdapter(Context context, List<UserModel> userData) {
        this.context = context;
        this.userData = userData;
    }

    public void setFilteredUser(List<UserModel> filteredUser){
        this.userData = filteredUser;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public UserAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.user_item, parent, false);
        return new UserAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserAdapter.ViewHolder holder, int position) {
        UserModel userModel = (UserModel) userData.get(holder.getAdapterPosition());

        holder.itemUserImg.setImageResource(userModel.getUser_image());
        holder.itemUserLastName.setText(userModel.getUser_last_name());
        holder.itemUserFirstName.setText(userModel.getUser_first_name());

        holder.userUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.user_update);

                EditText edtUpdateImage = dialog.findViewById(R.id.userImage);
                EditText edtUpdateRegistrationNumber = dialog.findViewById(R.id.userRegistrationNumber);
                EditText edtUpdateLastName = dialog.findViewById(R.id.userLastName);
                EditText edtUpdateFirstName = dialog.findViewById(R.id.userFirstName);
                EditText edtUpdatePhone = dialog.findViewById(R.id.userPhone);
                EditText edtUpdateBluetooth = dialog.findViewById(R.id.userBluetooth);
                TextView txtUpdateTitle = dialog.findViewById(R.id.userTitle);
                ImageView btnClose = dialog.findViewById(R.id.userAddClose);
                Button btnUpdateButton = dialog.findViewById(R.id.userButton);


                txtUpdateTitle.setText("Update User");

                btnUpdateButton.setText("Update");


                edtUpdateRegistrationNumber.setText(userData.get(holder.getAdapterPosition()).getUser_registration_number());
                edtUpdateLastName.setText(userData.get(holder.getAdapterPosition()).getUser_last_name());
                edtUpdateFirstName.setText(userData.get(holder.getAdapterPosition()).getUser_first_name());
                edtUpdatePhone.setText(userData.get(holder.getAdapterPosition()).getUser_phone());
                edtUpdateBluetooth.setText(userData.get(holder.getAdapterPosition()).getUser_bluetooth());

                btnUpdateButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String updateRegistrationNumber="", updateLastName="", updateFirstName="", updatePhone="", updateBluetooth="";

                        if(!edtUpdateRegistrationNumber.getText().toString().equals("")){
                            updateRegistrationNumber = edtUpdateRegistrationNumber.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter Registration Number", Toast.LENGTH_SHORT);
                        }
                        if(!edtUpdateLastName.getText().toString().equals("")){
                            updateLastName = edtUpdateLastName.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtUpdateLastName.getText().toString().equals("")){
                            updateLastName = edtUpdateLastName.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtUpdateFirstName.getText().toString().equals("")){
                            updateFirstName = edtUpdateFirstName.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter First Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtUpdatePhone.getText().toString().equals("")){
                            updatePhone = edtUpdatePhone.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtUpdateBluetooth.getText().toString().equals("")){
                            updateBluetooth = edtUpdateBluetooth.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }


                        userData.set(holder.getAdapterPosition(), new UserModel(userData.get(holder.getAdapterPosition()).getUser_image(), updateRegistrationNumber, updateLastName, updateFirstName, updatePhone, updateBluetooth));
                        notifyItemChanged(holder.getAdapterPosition());

                        dialog.dismiss();

                    }
                });

                btnClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();

            }
        });

        holder.userDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(context)
                        .setTitle("Delete User")
                        .setMessage("Are you sure want to delete ?")
                        .setIcon(R.drawable.ic_delete)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                userData.remove(holder.getAdapterPosition());
                                notifyItemRemoved(holder.getAdapterPosition());
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });

                builder.show();
            }
        });

        holder.userItemLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.user_edit);

                TextView edtEditRegistrationNumber = dialog.findViewById(R.id.userEditRegistrationNumber);
                TextView edtEditLastName = dialog.findViewById(R.id.userEditLastName);
                TextView edtEditFirstName = dialog.findViewById(R.id.userEditFirstName);
                TextView edtEditPhone = dialog.findViewById(R.id.userEditPhone);
                TextView edtEditBluetooth = dialog.findViewById(R.id.userEditBluetooth);
                ImageView btnClose = dialog.findViewById(R.id.userEditClose);
                Button btnEditButton = dialog.findViewById(R.id.userEditButton);


                edtEditRegistrationNumber.setText(userData.get(holder.getAdapterPosition()).getUser_registration_number());
                edtEditLastName.setText(userData.get(holder.getAdapterPosition()).getUser_last_name());
                edtEditFirstName.setText(userData.get(holder.getAdapterPosition()).getUser_first_name());
                edtEditPhone.setText(userData.get(holder.getAdapterPosition()).getUser_phone());
                edtEditBluetooth.setText(userData.get(holder.getAdapterPosition()).getUser_bluetooth());

                btnEditButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                btnClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return userData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView itemUserImg;
        ImageView userUpdate;
        ImageView userDelete;
        TextView itemUserLastName;
        TextView itemUserFirstName;
        LinearLayout userItemLeft;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemUserImg = itemView.findViewById(R.id.itemUserImg);
            userUpdate = itemView.findViewById(R.id.userUpdate);
            userDelete = itemView.findViewById(R.id.userDelete);
            itemUserLastName = itemView.findViewById(R.id.itemUserLastName);
            itemUserFirstName = itemView.findViewById(R.id.itemUserFirstName);
            userItemLeft = itemView.findViewById(R.id.userItemLeft);
        }
    }
}
