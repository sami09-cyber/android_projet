package bf.bagus.bluetoothdetection.vue;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import bf.bagus.bluetoothdetection.R;
import bf.bagus.bluetoothdetection.modele.UserModel;
import bf.bagus.bluetoothdetection.outils.MesOutils;

public class UserActivity extends AppCompatActivity {
    private RecyclerView recyclerUser;
    private UserAdapter userAdapter;
    private SearchView searchUser;
    private List<UserModel> userData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        userBackData();

        userAddData();
        userSearch();
        recyclerAdapter();
    }

    private void userBackData() {
        ImageView userBack = findViewById(R.id.userBack);

        userBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UserActivity.this, DashboardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }

    private void userAddData() {
        ImageView userAdd = findViewById(R.id.userAdd);

        userAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(UserActivity.this);
                dialog.setContentView(R.layout.user_update);
                EditText edtAddImage = dialog.findViewById(R.id.userImage);
                EditText edtAddRegistrationNumber = dialog.findViewById(R.id.userRegistrationNumber);
                EditText edtAddLastName = dialog.findViewById(R.id.userLastName);
                EditText edtAddFirstName = dialog.findViewById(R.id.userFirstName);
                EditText edtAddPhone = dialog.findViewById(R.id.userPhone);
                EditText edtAddBluetooth = dialog.findViewById(R.id.userBluetooth);
                ImageView btnClose = dialog.findViewById(R.id.userAddClose);
                Button btnAddButton = dialog.findViewById(R.id.userButton);

                btnAddButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String addRegistrationNumber="", addLastName="", addFirstName="", addPhone="", addBluetooth="";

                        if(!edtAddRegistrationNumber.getText().toString().equals("")){
                            addRegistrationNumber = edtAddRegistrationNumber.getText().toString();
                        }else{
                            MesOutils.showToast(UserActivity.this, "Please Enter Registration Number", Toast.LENGTH_SHORT);
                        }
                        if(!edtAddLastName.getText().toString().equals("")){
                            addLastName = edtAddLastName.getText().toString();
                        }else{
                            MesOutils.showToast(UserActivity.this, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtAddLastName.getText().toString().equals("")){
                            addLastName = edtAddLastName.getText().toString();
                        }else{
                            MesOutils.showToast(UserActivity.this, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtAddFirstName.getText().toString().equals("")){
                            addFirstName = edtAddFirstName.getText().toString();
                        }else{
                            MesOutils.showToast(UserActivity.this, "Please Enter First Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtAddPhone.getText().toString().equals("")){
                            addPhone = edtAddPhone.getText().toString();
                        }else{
                            MesOutils.showToast(UserActivity.this, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtAddBluetooth.getText().toString().equals("")){
                            addBluetooth = edtAddBluetooth.getText().toString();
                        }else{
                            MesOutils.showToast(UserActivity.this, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        userAdd(R.drawable.ic_widgets, addRegistrationNumber, addLastName, addFirstName, addPhone, addBluetooth);
                        userAdapter.notifyItemInserted(userData.size() -1);
                        recyclerUser.scrollToPosition(userData.size() -1);
                        dialog.dismiss();
                    }
                });

                btnClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });
    }

    private void userAdd(int ic_widgets, String addRegistrationNumber, String addLastName, String addFirstName, String addPhone, String addBluetooth) {
        userData.add(new UserModel(ic_widgets, addRegistrationNumber, addLastName, addFirstName, addPhone, addBluetooth));
    }

    private void userSearch() {
        searchUser = findViewById(R.id.searchUser);
        searchUser.clearFocus();
        searchUser.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                filterUser(s);
                return true;
            }
        });

        recyclerUser = (RecyclerView) findViewById(R.id.recyclerUser);
    }

    private void filterUser(String s) {
        List<UserModel> filteredUser = new ArrayList<>();
        for (UserModel itemUser : userData){
            if(itemUser.getUser_last_name().toLowerCase().contains(s.toLowerCase())){
                filteredUser.add(itemUser);
            }
        }

        if(filteredUser.isEmpty()){
            MesOutils.showToast(this, "No data found", Toast.LENGTH_LONG);
        }else{
            userAdapter.setFilteredUser(filteredUser);
        }
    }

    private void recyclerAdapter() {
        userData = new ArrayList<>();

        recyclerUser.setHasFixedSize(true);
        recyclerUser.setLayoutManager(new LinearLayoutManager(this));

        recyclerAddData();

        userAdapter = new UserAdapter(this, userData);
        recyclerUser.setAdapter(userAdapter);
    }

    private void recyclerAddData() {
        userAdd(R.drawable.ic_teacher, "M2022@007", "Odg", "Ali", "+226 78980239", "C3:G1:A3:h3");
        userAdd(R.drawable.ic_teacher, "M2022@007", "Odg", "Ali", "+226 78980239", "C3:G1:A3:h3");
        userAdd(R.drawable.ic_teacher, "M2022@007", "Odg", "Ali", "+226 78980239", "C3:G1:A3:h3");
        userAdd(R.drawable.ic_teacher, "M2022@007", "Odg", "Ali", "+226 78980239", "C3:G1:A3:h3");
        userAdd(R.drawable.ic_teacher, "M2022@007", "Odg", "Ali", "+226 78980239", "C3:G1:A3:h3");
        userAdd(R.drawable.ic_teacher, "M2022@007", "Odg", "Ali", "+226 78980239", "C3:G1:A3:h3");
    }
}