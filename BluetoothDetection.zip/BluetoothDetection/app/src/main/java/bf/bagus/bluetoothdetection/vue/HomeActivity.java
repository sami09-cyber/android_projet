package bf.bagus.bluetoothdetection.vue;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;

import bf.bagus.bluetoothdetection.R;
import bf.bagus.bluetoothdetection.outils.MesOutils;

public class HomeActivity extends AppCompatActivity {
    private int hour, minute;
    private Button btnBeginHour;
    private Button btnEndHour;
    private Button btnScan;

    private ArrayList<BluetoothDevice> bluetoothDevices = new ArrayList<>();
    private BluetoothAdapter bluetoothAdapter;
    private ArrayAdapter<String> listAdapter;

    public final int REQUEST_ENABLE_BLUETOOTH = 11;
    public final int REQUEST_ACCESS_COARSE_LOCATION = 1;
    ListView homeList;
    ArrayList<String> homeListValues = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        homeBackData();
        teacherSpinnerInit();
        moduleSpinnerInit();
        timePickerDialogInitData();

        btnScan = findViewById(R.id.homeScan);
        homeList = findViewById(R.id.homeList);

        listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        homeList.setAdapter(listAdapter);
        //**********************************
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        //blueData();
        checkBluetoothState();

        registerReceiver(devicesFoundReceiver, new IntentFilter(BluetoothDevice.ACTION_FOUND));
        registerReceiver(devicesFoundReceiver, new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_STARTED));
        registerReceiver(devicesFoundReceiver, new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED));

        btnScan.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingPermission")
            @Override
            public void onClick(View view) {
                if(bluetoothAdapter != null && bluetoothAdapter.isEnabled()){
                    if(checkCoarseLocationpermission()){
                        homeListValues.clear();
                        bluetoothAdapter.startDiscovery();
                    }
                }else{
                    checkBluetoothState();
                }
            }
        });

        checkCoarseLocationpermission();

    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(devicesFoundReceiver);
    }

    private boolean checkCoarseLocationpermission(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_COARSE_LOCATION}, REQUEST_ACCESS_COARSE_LOCATION);
            return false;
        }else{
            return true;
        }
    }

    @SuppressLint("MissingPermission")
    private void checkBluetoothState(){
        if(bluetoothAdapter == null){
            MesOutils.showToast(this, "Bluetooth is not supported", Toast.LENGTH_LONG);
        }else{
            if(bluetoothAdapter.isEnabled()){
                if(bluetoothAdapter.isDiscovering()){
                    MesOutils.showToast(this, "Device is discovering process...", Toast.LENGTH_LONG);
                }else{
                    MesOutils.showToast(this, "Bluetooth is enabled", Toast.LENGTH_LONG);
                    btnScan.setEnabled(true);
                }
            }else{
                MesOutils.showToast(this, "You need to enable Bluetooth", Toast.LENGTH_LONG);
                Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableIntent, REQUEST_ENABLE_BLUETOOTH);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_ENABLE_BLUETOOTH){
            checkBluetoothState();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode){
            case REQUEST_ACCESS_COARSE_LOCATION:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    MesOutils.showToast(this, "Access Coarse allowed. You can scan Bluetooth devices", Toast.LENGTH_LONG);
                }else{
                    MesOutils.showToast(this, "Access Coarse forbidden. You can't scan Bluetooth devices", Toast.LENGTH_LONG);
                }
                break;
        }
    }

    private final BroadcastReceiver devicesFoundReceiver = new BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if(BluetoothDevice.ACTION_FOUND.equals(action)){
                Log.d("Variable","hello");
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                listAdapter.add(device.getName()+"\n"+device.getAddress());
                listAdapter.notifyDataSetChanged();
            }else if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){
                btnScan.setText("Scanning Bluetooth devices");
            } else if(BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action)){
                btnScan.setText("Scanning in progress ...");
            }
        }
    };


    //    private void blueData(){
//
//        if(bluetoothAdapter == null){
//            MesOutils.showToast(this, "Bluetooth not supported", Toast.LENGTH_LONG);
//        }
//
//        if (!bluetoothAdapter.isEnabled()) {
//            Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
//            startActivityForResult(enableIntent, REQUEST_ENABLE_BLUETOOTH);
//        }
//
//        checkLocationPermission();
//
//        btnScan.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
//                    // TODO: Consider calling
//                    //    ActivityCompat#requestPermissions
//                    // here to request the missing permissions, and then overriding
//                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//                    //                                          int[] grantResults)
//                    // to handle the case where the user grants the permission. See the documentation
//                    // for ActivityCompat#requestPermissions for more details.
//                    return;
//                }
//                Set<BluetoothDevice> devices = bluetoothAdapter.getBondedDevices();
//
//                homeListValues.clear();
//
//                if (devices.size() > 0) {
//                    for (BluetoothDevice device : devices) {
//                        bluetoothDevices.add(device);
//                        homeListValues.add(device.getName()+"\n"+device.getAddress());
//                    }
//
//                    listAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, homeListValues);
//                    homeList.setAdapter(listAdapter);
//                }
//
//            }
//        });
//    }

//    private boolean checkLocationPermission() {
//        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
//            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_COARSE_LOCATION} , REQUEST_ACCESS_COARSE_LOCATION);
//            return false;
//        }else{
//            return true;
//        }
//
//    }


    private void homeBackData() {
        ImageView homeBack = findViewById(R.id.homeBack);

        homeBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, DashboardActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }

    private void timePickerDialogInitData() {
        btnBeginHour = findViewById(R.id.beginHour);
        btnEndHour = findViewById(R.id.endHour);

        btnBeginHour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timePickerDialogInit(btnBeginHour, "Begin");
            }
        });

        btnEndHour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timePickerDialogInit(btnEndHour, "End");
            }
        });
    }

    private void timePickerDialogInit(Button btn, String msg) {
        TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int i, int i1) {
                hour = i;
                minute = i1;
                btn.setText(String.format(Locale.getDefault(), "%02d:%02d", hour, minute));
            }
        };
        TimePickerDialog timePickerDialog = new TimePickerDialog(this, onTimeSetListener, hour, minute, true);
        timePickerDialog.setTitle(msg);
        timePickerDialog.show();
    }

    private void moduleSpinnerInit() {
        ArrayList<String> moduleSpinnerValues = new ArrayList<>();
        Spinner moduleSpinner = findViewById(R.id.moduleSpinner);

        moduleSpinnerValues.add("English");
        moduleSpinnerValues.add("Algebra");
        moduleSpinnerValues.add("Analysis");

        ArrayAdapter<String> moduleSpinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, moduleSpinnerValues);
        moduleSpinner.setAdapter(moduleSpinnerAdapter);
    }

    private void teacherSpinnerInit() {
        ArrayList<String> teacherSpinnerValues = new ArrayList<>();
        Spinner teacherSpinner = findViewById(R.id.teacherSpinner);

        teacherSpinnerValues.add("Lundi");
        teacherSpinnerValues.add("Mardi");
        teacherSpinnerValues.add("Mercredi");

        ArrayAdapter<String> teacherSpinnerAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, teacherSpinnerValues);
        teacherSpinner.setAdapter(teacherSpinnerAdapter);
    }
}