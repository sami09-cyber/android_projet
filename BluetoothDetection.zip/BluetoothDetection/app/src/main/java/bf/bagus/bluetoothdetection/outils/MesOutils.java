package bf.bagus.bluetoothdetection.outils;

import android.content.Context;
import android.widget.Toast;

public abstract class MesOutils {

    public static void showToast(Context context, String message, int during){
        Toast.makeText(context, message, during).show();
    }


}
