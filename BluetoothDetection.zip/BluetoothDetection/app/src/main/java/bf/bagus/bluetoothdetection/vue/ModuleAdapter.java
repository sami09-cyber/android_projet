package bf.bagus.bluetoothdetection.vue;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import bf.bagus.bluetoothdetection.R;
import bf.bagus.bluetoothdetection.modele.ModuleModel;
import bf.bagus.bluetoothdetection.outils.MesOutils;

public class ModuleAdapter extends RecyclerView.Adapter<ModuleAdapter.ViewHolder> {
    Context context;
    public List<ModuleModel> moduleData;

    public ModuleAdapter(Context context, List<ModuleModel> moduleData) {
        this.context = context;
        this.moduleData = moduleData;
    }

    public void setFilteredModule(List<ModuleModel> filteredModule){
        this.moduleData = filteredModule;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ModuleAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.module_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ModuleAdapter.ViewHolder holder, int position) {
        ModuleModel moduleModel = (ModuleModel) moduleData.get(holder.getAdapterPosition());

        holder.itemModuleImg.setImageResource(moduleModel.getModule_image_id());
        holder.itemModuleName.setText(moduleModel.getModule_name());
        holder.itemModuleDescription.setText(moduleModel.getModule_description());

        holder.moduleUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.module_update);

                EditText edtUpdateImage = dialog.findViewById(R.id.moduleImage);
                EditText edtUpdateName = dialog.findViewById(R.id.moduleName);
                EditText edtUpdateDescription = dialog.findViewById(R.id.moduleDescription);
                TextView txtUpdateTitle = dialog.findViewById(R.id.moduleTitle);
                ImageView btnClose = dialog.findViewById(R.id.moduleAddClose);
                Button btnUpdateButton = dialog.findViewById(R.id.moduleButton);


                txtUpdateTitle.setText("Update Module");

                btnUpdateButton.setText("Update");


                edtUpdateName.setText(moduleData.get(holder.getAdapterPosition()).getModule_name());
                edtUpdateDescription.setText(moduleData.get(holder.getAdapterPosition()).getModule_description());

                btnUpdateButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String updateImage="", updateName="", updateDescription="";
//                        if(!edtUpdateImage.getText().toString().equals("")){
//                            updateImage = edtUpdateImage.getText().toString();
//                        }else{
//                            MesOutils.showToast(ModuleActivity.this, "Please Enter Module Image !", Toast.LENGTH_SHORT);
//                        }
                        if(!edtUpdateName.getText().toString().equals("")){
                            updateName = edtUpdateName.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter Module Name", Toast.LENGTH_SHORT);
                        }
                        if(!edtUpdateDescription.getText().toString().equals("")){
                            updateDescription = edtUpdateDescription.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter Module Description", Toast.LENGTH_SHORT);
                        }

                        moduleData.set(holder.getAdapterPosition(), new ModuleModel(moduleData.get(holder.getAdapterPosition()).getModule_image_id(), updateName, updateDescription));
                        notifyItemChanged(holder.getAdapterPosition());

                        dialog.dismiss();

                    }
                });

                btnClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });

        holder.moduleDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(context)
                        .setTitle("Delete Module")
                        .setMessage("Are you sure want to delete ?")
                        .setIcon(R.drawable.ic_delete)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                moduleData.remove(holder.getAdapterPosition());
                                notifyItemRemoved(holder.getAdapterPosition());
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });

                builder.show();
            }
        });

        holder.moduleItemLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.module_edit);

                TextView edtEditName = dialog.findViewById(R.id.moduleEditName);
                TextView edtEditDescription = dialog.findViewById(R.id.moduleEditDescription);
                ImageView btnClose = dialog.findViewById(R.id.moduleEditClose);
                Button btnEditButton = dialog.findViewById(R.id.moduleEditButton);


                edtEditName.setText(moduleData.get(holder.getAdapterPosition()).getModule_name());
                edtEditDescription.setText(moduleData.get(holder.getAdapterPosition()).getModule_description());

                btnEditButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                btnClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return moduleData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView itemModuleImg;
        ImageView moduleUpdate;
        ImageView moduleDelete;
        TextView itemModuleName;
        TextView itemModuleDescription;
        LinearLayout moduleItemLeft;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemModuleImg = itemView.findViewById(R.id.itemModuleImg);
            moduleUpdate = itemView.findViewById(R.id.moduleUpdate);
            moduleDelete = itemView.findViewById(R.id.moduleDelete);
            itemModuleName = itemView.findViewById(R.id.itemModuleName);
            itemModuleDescription = itemView.findViewById(R.id.itemModuleDescription);
            moduleItemLeft = itemView.findViewById(R.id.moduleItemLeft);
        }
    }
}
