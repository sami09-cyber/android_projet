package bf.bagus.bluetoothdetection.vue;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import bf.bagus.bluetoothdetection.R;
import bf.bagus.bluetoothdetection.modele.ModuleModel;
import bf.bagus.bluetoothdetection.modele.TeacherModel;
import bf.bagus.bluetoothdetection.outils.MesOutils;

public class TeacherAdapter extends RecyclerView.Adapter<TeacherAdapter.ViewHolder> {
    Context context;
    public List<TeacherModel> teacherData;

    public TeacherAdapter(Context context, List<TeacherModel> teacherData) {
        this.context = context;
        this.teacherData = teacherData;
    }

    public void setFilteredTeacher(List<TeacherModel> filteredTeacher){
        this.teacherData = filteredTeacher;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TeacherAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.teacher_item, parent, false);
        return new TeacherAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TeacherAdapter.ViewHolder holder, int position) {
        TeacherModel teacherModel = (TeacherModel) teacherData.get(holder.getAdapterPosition());

        holder.itemTeacherImg.setImageResource(teacherModel.getTeacher_image());
        holder.itemTeacherLastName.setText(teacherModel.getTeacher_last_name());
        holder.itemTeacherFirstName.setText(teacherModel.getTeacher_first_name());

        holder.teacherUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.teacher_update);

                EditText edtUpdateImage = dialog.findViewById(R.id.teacherImage);
                EditText edtUpdateRegistrationNumber = dialog.findViewById(R.id.teacherRegistrationNumber);
                EditText edtUpdateLastName = dialog.findViewById(R.id.teacherLastName);
                EditText edtUpdateFirstName = dialog.findViewById(R.id.teacherFirstName);
                EditText edtUpdatePhone = dialog.findViewById(R.id.teacherPhone);
                TextView txtUpdateTitle = dialog.findViewById(R.id.teacherTitle);
                ImageView btnClose = dialog.findViewById(R.id.teacherAddClose);
                Button btnUpdateButton = dialog.findViewById(R.id.teacherButton);


                txtUpdateTitle.setText("Update Teacher");

                btnUpdateButton.setText("Update");


                edtUpdateRegistrationNumber.setText(teacherData.get(holder.getAdapterPosition()).getTeacher_registration_number());
                edtUpdateLastName.setText(teacherData.get(holder.getAdapterPosition()).getTeacher_last_name());
                edtUpdateFirstName.setText(teacherData.get(holder.getAdapterPosition()).getTeacher_first_name());
                edtUpdatePhone.setText(teacherData.get(holder.getAdapterPosition()).getTeacher_phone());

                btnUpdateButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String updateRegistrationNumber="", updateLastName="", updateFirstName="", updatePhone="";

                        if(!edtUpdateRegistrationNumber.getText().toString().equals("")){
                            updateRegistrationNumber = edtUpdateRegistrationNumber.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter Registration Number", Toast.LENGTH_SHORT);
                        }
                        if(!edtUpdateLastName.getText().toString().equals("")){
                            updateLastName = edtUpdateLastName.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtUpdateLastName.getText().toString().equals("")){
                            updateLastName = edtUpdateLastName.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtUpdateFirstName.getText().toString().equals("")){
                            updateFirstName = edtUpdateFirstName.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter First Name", Toast.LENGTH_SHORT);
                        }

                        if(!edtUpdatePhone.getText().toString().equals("")){
                            updatePhone = edtUpdatePhone.getText().toString();
                        }else{
                            MesOutils.showToast(context, "Please Enter Last Name", Toast.LENGTH_SHORT);
                        }

                        teacherData.set(holder.getAdapterPosition(), new TeacherModel(teacherData.get(holder.getAdapterPosition()).getTeacher_image(), updateRegistrationNumber, updateLastName, updateFirstName, updatePhone));
                        notifyItemChanged(holder.getAdapterPosition());

                        dialog.dismiss();

                    }
                });

                btnClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();

            }
        });

        holder.teacherDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder builder = new AlertDialog.Builder(context)
                        .setTitle("Delete Teacher")
                        .setMessage("Are you sure want to delete ?")
                        .setIcon(R.drawable.ic_delete)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                teacherData.remove(holder.getAdapterPosition());
                                notifyItemRemoved(holder.getAdapterPosition());
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });

                builder.show();
            }
        });

        holder.teacherItemLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.teacher_edit);

                TextView edtEditRegistrationNumber = dialog.findViewById(R.id.teacherEditRegistrationNumber);
                TextView edtEditLastName = dialog.findViewById(R.id.teacherEditLastName);
                TextView edtEditFirstName = dialog.findViewById(R.id.teacherEditFirstName);
                TextView edtEditPhone = dialog.findViewById(R.id.teacherEditPhone);
                ImageView btnClose = dialog.findViewById(R.id.teacherEditClose);
                Button btnEditButton = dialog.findViewById(R.id.teacherEditButton);


                edtEditRegistrationNumber.setText(teacherData.get(holder.getAdapterPosition()).getTeacher_registration_number());
                edtEditLastName.setText(teacherData.get(holder.getAdapterPosition()).getTeacher_last_name());
                edtEditFirstName.setText(teacherData.get(holder.getAdapterPosition()).getTeacher_first_name());
                edtEditPhone.setText(teacherData.get(holder.getAdapterPosition()).getTeacher_phone());

                btnEditButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                btnClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                dialog.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return teacherData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView itemTeacherImg;
        ImageView teacherUpdate;
        ImageView teacherDelete;
        TextView itemTeacherLastName;
        TextView itemTeacherFirstName;
        LinearLayout teacherItemLeft;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemTeacherImg = itemView.findViewById(R.id.itemTeacherImg);
            teacherUpdate = itemView.findViewById(R.id.teacherUpdate);
            teacherDelete = itemView.findViewById(R.id.teacherDelete);
            itemTeacherLastName = itemView.findViewById(R.id.itemTeacherLastName);
            itemTeacherFirstName = itemView.findViewById(R.id.itemTeacherFirstName);
            teacherItemLeft = itemView.findViewById(R.id.teacherItemLeft);
        }
    }
}
